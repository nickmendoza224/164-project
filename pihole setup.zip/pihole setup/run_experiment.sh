#!/bin/bash

echo "Starting capture..."
sudo ./run_capture.sh &
CAP_PID=$!

sleep 2

echo "Generating traffic..."
./run_sites.sh

sleep 5

echo "Stopping capture..."
kill $CAP_PID

echo "Done. Now run convert.sh"
