#!/bin/bash

echo "=== Pi-hole Docker Setup ==="

# Step 1: Stop and remove old containers
echo "[1/3] Cleaning old containers..."
docker-compose down 2>/dev/null

# Step 2: Start fresh container
echo "[2/3] Starting Pi-hole..."
docker-compose up -d

# Step 3: Verify container is running
echo "[3/3] Checking container status..."
docker ps | grep pihole

echo ""
echo "=== Setup Complete ==="
echo "Open: http://localhost/admin"
echo "Password: admin"
echo ""
echo "NEXT STEP:"
echo "Set your DNS to this machine (127.0.0.1)"