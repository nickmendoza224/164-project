#!/bin/bash

sites=(
  "youtube.com"
  "google.com"
  "facebook.com"
  "reddit.com"
  "amazon.com"
  "netflix.com"
  "twitter.com"
  "instagram.com"
  "yahoo.com"
  "wikipedia.org"
  "doubleclick.net"
  "ads.google.com"
 
)

for site in "${sites[@]}"
do
  echo "Visiting $site"
  dig @127.0.0.1 -p 5300 $site
  sleep 2
done

echo "Done generating traffic"
