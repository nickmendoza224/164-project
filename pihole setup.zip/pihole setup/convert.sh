#!/bin/bash

INPUT=$1
OUTPUT="${INPUT%.pcap}.csv"

tshark -r $INPUT -T fields \
-e frame.time \
-e ip.src \
-e ip.dst \
-e dns.qry.name \
> $OUTPUT