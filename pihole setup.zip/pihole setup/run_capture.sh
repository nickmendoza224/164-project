#!/bin/bash

TIMESTAMP=$(date +"%Y-%m-%d_%H-%M-%S")
FILE="dns_capture_$TIMESTAMP.pcap"

echo "====================================="
echo "Starting DNS Capture"
echo "Date: $(date +"%Y-%m-%d")"
echo "Time: $(date +"%H:%M:%S")"
echo "File: $FILE"
echo "====================================="

# Log it (this is the important part)
echo "RUN | $TIMESTAMP | $FILE" >> experiment_log.txt

sudo tcpdump -i any port 53 -w $FILE
